# 🚨 IMPORTANT: How to Properly Deploy SkillUpWorks

## ❌ The Issue You Encountered

The build failed because the **Dockerfiles were not in the service directories**. 

The error: `open Dockerfile: no such file or directory`

## ✅ The Solution: Proper File Organization

You need to ensure **Dockerfiles are inside each service directory** before running `docker-compose build`.

---

## 📁 Required Directory Structure

```
~/skillupworks/
├── docker-compose.yml              ✅ In root
├── prepare.sh                      ✅ In root
├── setup.sh                        ✅ In root
├── deploy.sh                       ✅ In root
│
├── catalogue-service/
│   └── Dockerfile                  ⚠️ MUST BE HERE
│
├── user-service/
│   └── Dockerfile                  ⚠️ MUST BE HERE
│
├── cart-service/
│   └── Dockerfile                  ⚠️ MUST BE HERE
│
├── payment-service/
│   └── Dockerfile                  ⚠️ MUST BE HERE
│
├── order-processor/
│   └── Dockerfile                  ⚠️ MUST BE HERE
│
├── shipping-service/
│   └── Dockerfile                  ⚠️ MUST BE HERE
│
└── frontend/
    ├── Dockerfile                  ⚠️ MUST BE HERE
    └── nginx.conf                  ⚠️ MUST BE HERE
```

---

## 🔧 Two Ways to Fix This

### Option 1: Use prepare.sh (Recommended)

I've created a **prepare.sh** script that organizes everything for you:

```bash
cd ~/skillupworks

# Step 1: Run prepare.sh first
chmod +x prepare.sh
./prepare.sh
# This creates directories and copies Dockerfiles

# Step 2: Run setup.sh (downloads source code)
./setup.sh

# Step 3: Run deploy.sh (builds and deploys)
./deploy.sh
```

**Total: 3 commands** ✅

---

### Option 2: Manually Copy Dockerfiles

If you downloaded the files separately:

```bash
cd ~/skillupworks

# Copy each Dockerfile to its service directory
cp Dockerfile.catalogue catalogue-service/Dockerfile
cp Dockerfile.user user-service/Dockerfile
cp Dockerfile.cart cart-service/Dockerfile
cp Dockerfile.payment payment-service/Dockerfile
cp Dockerfile.order-processor order-processor/Dockerfile
cp Dockerfile.shipping shipping-service/Dockerfile
cp Dockerfile.frontend frontend/Dockerfile
cp nginx.conf frontend/

# Then run setup and deploy
./setup.sh
./deploy.sh
```

---

## 📦 Complete Deployment Steps (Corrected)

### Prerequisites
```bash
# Install Docker & Docker Compose (one-time)
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
```

### Deployment
```bash
# 1. Create directory and upload files
mkdir ~/skillupworks && cd ~/skillupworks
# Upload all files here

# 2. Make scripts executable
chmod +x prepare.sh setup.sh deploy.sh

# 3. Run in order
./prepare.sh    # Organizes Dockerfiles
./setup.sh      # Downloads source code from S3
./deploy.sh     # Builds and deploys everything

# 4. Access
http://<YOUR-SERVER-IP>
```

---

## ✅ Verification Checklist

Before running docker-compose, verify:

```bash
# Check Dockerfiles exist
ls -la catalogue-service/Dockerfile
ls -la user-service/Dockerfile
ls -la cart-service/Dockerfile
ls -la payment-service/Dockerfile
ls -la order-processor/Dockerfile
ls -la shipping-service/Dockerfile
ls -la frontend/Dockerfile
ls -la frontend/nginx.conf

# All should show files, not "No such file"
```

---

## 🐛 If You Still Get Errors

### Error: "open Dockerfile: no such file or directory"
**Cause:** Dockerfile not in service directory  
**Fix:** Run `./prepare.sh` or manually copy Dockerfiles

### Error: "package.json not found"
**Cause:** Source code not downloaded  
**Fix:** Run `./setup.sh` to download from S3

### Error: "docker-compose.yml not found"
**Cause:** Not in correct directory  
**Fix:** `cd ~/skillupworks` (or wherever you extracted files)

---

## 📝 Complete Command Sequence

```bash
# On your server
cd ~
mkdir skillupworks && cd skillupworks

# Upload/extract all Docker package files here

# Run these 3 commands in order
chmod +x prepare.sh setup.sh deploy.sh
./prepare.sh && ./setup.sh && ./deploy.sh

# Wait 10-15 minutes
# Access: http://<SERVER_IP>
```

---

## 🎯 Why 3 Scripts?

1. **prepare.sh** - Organizes Dockerfiles into correct directories
2. **setup.sh** - Downloads source code from S3 (7 ZIPs)
3. **deploy.sh** - Builds Docker images and starts all services

**Each has a specific purpose and must run in order!**

---

## 💡 Alternative: All-in-One

If you want ONE command, you can chain them:

```bash
./prepare.sh && ./setup.sh && ./deploy.sh
```

This runs all three scripts sequentially. ✅

---

## 📞 Still Having Issues?

1. Check you're in the correct directory: `pwd` should show `.../skillupworks`
2. Verify files downloaded: `ls -la` should show all scripts and docker-compose.yml
3. Check Docker is running: `docker ps`
4. View detailed errors: Check the output carefully

---

## ✨ Summary

**The fix:** Run `./prepare.sh` BEFORE running `./deploy.sh`

**Correct order:**
1. `./prepare.sh` → Organizes Dockerfiles ✅
2. `./setup.sh` → Downloads source code ✅
3. `./deploy.sh` → Builds & deploys ✅

**Time:** ~15 minutes total

**Result:** All 11 services running! 🎉
