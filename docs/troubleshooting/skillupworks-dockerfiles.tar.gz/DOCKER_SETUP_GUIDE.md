# SkillUpWorks Docker Compose Setup Guide

Complete deployment guide for running all 11 SkillUpWorks microservices with Docker Compose on a single server.

---

## Table of Contents
- [Prerequisites](#prerequisites)
- [Project Structure](#project-structure)
- [Setup Instructions](#setup-instructions)
- [Deployment](#deployment)
- [Verification](#verification)
- [Troubleshooting](#troubleshooting)
- [Service Management](#service-management)

---

## Prerequisites

### Server Requirements
- **OS:** Ubuntu 20.04+ / RHEL 8+ / Amazon Linux 2023
- **Instance Type:** t3.large or larger (minimum 8GB RAM, 4 vCPU)
- **Disk Space:** 50GB minimum
- **Ports:** 80, 5672, 8081-8086, 15672, 27017 (open in security group)

### Software Requirements
```bash
# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Verify installations
docker --version
docker-compose --version
```

---

## Project Structure

Create this directory structure on your server:

```
skillupworks/
├── docker-compose.yml
├── .env
│
├── catalogue-service/
│   ├── Dockerfile
│   ├── package.json
│   ├── server.js
│   └── schema/
│       └── catalogue.js
│
├── user-service/
│   ├── Dockerfile
│   ├── package.json
│   ├── server.js
│   └── schema/
│       └── user.js
│
├── cart-service/
│   ├── Dockerfile
│   ├── package.json
│   └── server.js
│
├── payment-service/
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── payment.py
│   └── payment.ini
│
├── order-processor/
│   ├── Dockerfile
│   ├── requirements.txt
│   └── order_processor.py
│
├── shipping-service/
│   ├── Dockerfile
│   ├── pom.xml
│   ├── src/
│   └── schema/
│       └── shipping.sql
│
├── frontend/
│   ├── Dockerfile
│   ├── nginx.conf
│   └── html/
│       ├── index.html
│       ├── css/
│       ├── js/
│       └── media/
│
├── mongo-init/
│   └── init-db.js
│
└── mysql-init/
    └── shipping.sql
```

---

## Setup Instructions

### Step 1: Create Base Directory

```bash
# Create project directory
mkdir -p ~/skillupworks
cd ~/skillupworks
```

### Step 2: Download Source Code

**Option A: From S3 (if you have the ZIPs)**
```bash
# Create service directories
mkdir -p catalogue-service user-service cart-service payment-service order-processor shipping-service frontend

# Download and extract each service
cd catalogue-service
curl -o service.zip https://skillupworks.s3.us-east-1.amazonaws.com/skillupworks-catalogue.zip
unzip service.zip && rm service.zip

cd ../user-service
curl -o service.zip https://skillupworks.s3.us-east-1.amazonaws.com/skillupworks-user.zip
unzip service.zip && rm service.zip

# Repeat for other services...
```

**Option B: From GitHub**
```bash
# Clone your repository
git clone https://github.com/telugutechvidya/cloudkart-microservices.git
cd cloudkart-microservices

# Copy to project structure
# (Adjust paths based on your repo structure)
```

### Step 3: Copy Docker Files

Copy all the Dockerfiles and docker-compose.yml to their respective directories:

```bash
# Copy docker-compose.yml to project root
cp docker-compose.yml ~/skillupworks/

# Copy Dockerfiles to each service directory
cp catalogue-service/Dockerfile ~/skillupworks/catalogue-service/
cp user-service/Dockerfile ~/skillupworks/user-service/
cp cart-service/Dockerfile ~/skillupworks/cart-service/
cp payment-service/Dockerfile ~/skillupworks/payment-service/
cp order-processor/Dockerfile ~/skillupworks/order-processor/
cp shipping-service/Dockerfile ~/skillupworks/shipping-service/
cp frontend/Dockerfile ~/skillupworks/frontend/
cp frontend/nginx.conf ~/skillupworks/frontend/
```

### Step 4: Create Database Init Scripts

**MongoDB Init (mongo-init/init-db.js):**
```bash
mkdir -p ~/skillupworks/mongo-init

cat > ~/skillupworks/mongo-init/init-db.js << 'EOF'
// Initialize MongoDB databases and collections
// This runs automatically when MongoDB container starts

// Switch to catalogue database
db = db.getSiblingDB('catalogue');

// Create products collection with sample data
db.products.insertMany([
  {
    sku: "Linux",
    name: "Linux Mastery",
    description: "Complete Linux administration from basics to advanced",
    price: 2999,
    image: "/images/linux.jpg",
    category: "DevOps",
    qty: 100
  },
  {
    sku: "Docker",
    name: "Docker Mastery: From Code to Containers",
    description: "Master containerization with Docker",
    price: 2999,
    image: "/images/docker.jpg",
    category: "DevOps",
    qty: 100
  },
  {
    sku: "Kubernetes",
    name: "Kubernetes In Action: Scale Like Netflix",
    description: "Production-grade Kubernetes orchestration",
    price: 3999,
    image: "/images/kubernetes.jpg",
    category: "DevOps",
    qty: 100
  },
  {
    sku: "Ansible",
    name: "Ansible Mastery: One Click, Everything",
    description: "Automate infrastructure with Ansible",
    price: 2999,
    image: "/images/ansible.jpg",
    category: "DevOps",
    qty: 100
  },
  {
    sku: "Terraform",
    name: "Terraform Mastery: Build Cloud With Code",
    description: "Infrastructure as Code with Terraform",
    price: 2999,
    image: "/images/terraform.jpg",
    category: "DevOps",
    qty: 100
  }
]);

// Create indexes
db.products.createIndex({ sku: 1 }, { unique: true });
db.products.createIndex({ name: "text", description: "text" });

print("Catalogue database initialized with sample products");

// Switch to users database
db = db.getSiblingDB('users');

// Create users collection (empty, will be populated on registration)
db.createCollection('users');

// Create indexes
db.users.createIndex({ username: 1 }, { unique: true });
db.users.createIndex({ email: 1 }, { unique: true });

print("Users database initialized");
EOF
```

**MySQL Init (mysql-init/shipping.sql):**
```bash
mkdir -p ~/skillupworks/mysql-init

# Copy your shipping.sql file (with 208k cities data)
# This should be the actual shipping.sql from your GitHub repo
cp /path/to/shipping.sql ~/skillupworks/mysql-init/
```

### Step 5: Update Payment Service Configuration

Create a proper payment.ini if not present:

```bash
cat > ~/skillupworks/payment-service/payment.ini << 'EOF'
[uwsgi]
module = payment:app
master = true
processes = 4
threads = 2
http = 0.0.0.0:8084
protocol = http
chmod-socket = 660
vacuum = true
die-on-term = true
EOF
```

---

## Deployment

### Step 1: Build All Services

```bash
cd ~/skillupworks

# Build all images (this may take 10-20 minutes)
docker-compose build

# Check built images
docker images | grep skillupworks
```

### Step 2: Start All Services

```bash
# Start all services in background
docker-compose up -d

# Watch logs in real-time
docker-compose logs -f
```

### Step 3: Monitor Startup

Services will start in order based on dependencies:

1. **Databases** (MongoDB, Redis, MySQL, RabbitMQ) - 30-60 seconds
2. **Backend Services** (Catalogue, User, Cart) - 30-60 seconds
3. **Payment & Shipping** - 30-60 seconds
4. **Order Processor** - 10 seconds
5. **Frontend (Nginx)** - 10 seconds

**Total startup time: 2-3 minutes**

---

## Verification

### Step 1: Check Container Status

```bash
# Check all containers are running
docker-compose ps

# Expected output: All services should be "Up" and "healthy"
```

### Step 2: Test Individual Services

```bash
# Get your server's public IP
SERVER_IP=$(curl -s http://checkip.amazonaws.com)
echo "Server IP: $SERVER_IP"

# Test Catalogue Service
curl http://localhost:8082/health
curl http://localhost:8082/products

# Test User Service
curl http://localhost:8081/health

# Test Cart Service
curl http://localhost:8083/health

# Test Payment Service
curl http://localhost:8084/health

# Test Shipping Service
curl http://localhost:8086/actuator/health
curl http://localhost:8086/count

# Test RabbitMQ Management UI
curl http://localhost:15672
# Web UI: http://<SERVER_IP>:15672
# Login: skillupworks / skillupworks@123
```

### Step 3: Test Complete Application

```bash
# Access frontend
curl http://localhost/

# Or open in browser
echo "Open: http://$SERVER_IP"
```

### Step 4: Test End-to-End Flow

1. **Register User**
   - Go to http://<SERVER_IP>
   - Click "Login / Register"
   - Register new account

2. **Browse Products**
   - View product categories
   - Click on products

3. **Add to Cart**
   - Add items to cart
   - View cart

4. **Checkout**
   - Process payment
   - Verify order

5. **Check Order Processing**
   ```bash
   # View order processor logs
   docker-compose logs -f order-processor
   
   # Should show order processing after payment
   ```

---

## Troubleshooting

### Issue: Containers Fail to Start

```bash
# Check logs
docker-compose logs <service-name>

# Example
docker-compose logs mongodb
docker-compose logs payment
```

### Issue: Port Already in Use

```bash
# Find process using port
sudo netstat -tulpn | grep <PORT>

# Kill process
sudo kill -9 <PID>

# Or change port in docker-compose.yml
```

### Issue: MongoDB Connection Failed

```bash
# Check MongoDB logs
docker-compose logs mongodb

# Restart MongoDB
docker-compose restart mongodb

# Wait for healthy status
docker-compose ps mongodb
```

### Issue: Service Shows "Unhealthy"

```bash
# Check health check logs
docker inspect --format='{{json .State.Health}}' skillupworks-<service>

# Restart service
docker-compose restart <service>
```

### Issue: Out of Memory

```bash
# Check memory usage
docker stats

# Increase server memory or reduce container limits
# Edit docker-compose.yml to add memory limits

# Example:
services:
  shipping:
    mem_limit: 2g
```

### Issue: Build Fails

```bash
# Clean and rebuild
docker-compose down
docker system prune -a
docker-compose build --no-cache
docker-compose up -d
```

---

## Service Management

### Start/Stop Services

```bash
# Start all services
docker-compose start

# Stop all services
docker-compose stop

# Restart all services
docker-compose restart

# Restart specific service
docker-compose restart payment
```

### View Logs

```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f payment

# Last 100 lines
docker-compose logs --tail=100 payment
```

### Scale Services

```bash
# Scale order-processor to 3 instances
docker-compose up -d --scale order-processor=3

# Scale back to 1
docker-compose up -d --scale order-processor=1
```

### Update a Service

```bash
# 1. Make code changes
# 2. Rebuild the service
docker-compose build <service>

# 3. Recreate container
docker-compose up -d --no-deps <service>

# Example: Update payment service
docker-compose build payment
docker-compose up -d --no-deps payment
```

### Clean Up

```bash
# Stop and remove containers
docker-compose down

# Remove containers and volumes (CAUTION: deletes data!)
docker-compose down -v

# Remove containers, volumes, and images
docker-compose down -v --rmi all
```

---

## Performance Tuning

### Resource Limits

Add to docker-compose.yml:

```yaml
services:
  shipping:
    mem_limit: 2g
    mem_reservation: 1g
    cpus: 2
```

### Database Optimization

**MongoDB:**
```yaml
mongodb:
  command: mongod --wiredTigerCacheSizeGB 1
```

**MySQL:**
```yaml
mysql:
  command: --innodb-buffer-pool-size=512M --max-connections=200
```

---

## Backup and Restore

### Backup Data

```bash
# Backup MongoDB
docker exec skillupworks-mongodb mongodump --out /backup
docker cp skillupworks-mongodb:/backup ./mongodb-backup

# Backup MySQL
docker exec skillupworks-mysql mysqldump -u root -pskillupworks@1990 cities > mysql-backup.sql

# Backup Redis
docker exec skillupworks-redis redis-cli SAVE
docker cp skillupworks-redis:/data/dump.rdb ./redis-backup.rdb
```

### Restore Data

```bash
# Restore MongoDB
docker cp ./mongodb-backup skillupworks-mongodb:/backup
docker exec skillupworks-mongodb mongorestore /backup

# Restore MySQL
docker exec -i skillupworks-mysql mysql -u root -pskillupworks@1990 cities < mysql-backup.sql
```

---

## Monitoring

### Container Stats

```bash
# Real-time resource usage
docker stats

# Specific service
docker stats skillupworks-payment
```

### Application Metrics

- **RabbitMQ UI:** http://<SERVER_IP>:15672
- **Service Health:** http://<SERVER_IP>:8081/health (each service)

---

## Security Best Practices

1. **Change Default Passwords:**
   - MongoDB: No password by default (add in production)
   - MySQL: skillupworks@1990 → Change to strong password
   - RabbitMQ: skillupworks@123 → Change to strong password

2. **Use Environment Variables:**
   - Create `.env` file for sensitive data
   - Don't commit `.env` to version control

3. **Enable HTTPS:**
   - Add SSL certificate to Nginx
   - Use Let's Encrypt for free SSL

4. **Firewall Rules:**
   - Only expose port 80/443 publicly
   - Keep database ports private

---

## Production Checklist

- [ ] Change all default passwords
- [ ] Enable SSL/HTTPS
- [ ] Set up automated backups
- [ ] Configure log rotation
- [ ] Set resource limits
- [ ] Enable monitoring/alerting
- [ ] Document custom configurations
- [ ] Test disaster recovery
- [ ] Set up CI/CD pipeline
- [ ] Review security settings

---

## Support

**For issues:**
1. Check logs: `docker-compose logs -f <service>`
2. Verify network: `docker network inspect skillupworks_skillupworks-network`
3. Check GitHub documentation
4. Review troubleshooting section above

---

## Summary

You now have a complete Docker Compose setup for SkillUpWorks with:

✅ All 11 microservices running on one server  
✅ Automatic service dependencies and health checks  
✅ Data persistence with Docker volumes  
✅ Easy deployment with one command  
✅ Scalable architecture  
✅ Complete isolation between services  

**Deploy command:**
```bash
docker-compose up -d
```

**Access application:**
```bash
http://<YOUR-SERVER-IP>
```

**That's it! Your SkillUpWorks application is now running!** 🎉
