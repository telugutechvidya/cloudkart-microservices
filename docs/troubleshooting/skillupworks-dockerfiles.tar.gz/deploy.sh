#!/bin/bash

# ============================================================================
# SkillUpWorks - Quick Deploy Script
# Automates the complete deployment of all 11 microservices
# ============================================================================

set -e  # Exit on error

echo "============================================"
echo "SkillUpWorks - Docker Compose Deployment"
echo "============================================"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Helper functions
print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${YELLOW}ℹ${NC} $1"
}

# Check if setup has been run (check for both source code AND Dockerfiles)
SETUP_NEEDED=false

if [ ! -f "catalogue-service/package.json" ] || [ ! -f "catalogue-service/Dockerfile" ]; then
    SETUP_NEEDED=true
fi

if [ "$SETUP_NEEDED" = true ]; then
    echo ""
    print_error "Setup not complete! Source code and/or Dockerfiles missing."
    echo ""
    print_info "Running setup.sh to download source code and prepare files..."
    echo ""
    
    if [ ! -f "setup.sh" ]; then
        print_error "setup.sh not found in current directory!"
        echo ""
        echo "Please ensure you have all required files:"
        echo "  - setup.sh"
        echo "  - deploy.sh"
        echo "  - docker-compose.yml"
        echo "  - All service Dockerfiles"
        exit 1
    fi
    
    chmod +x setup.sh
    if ./setup.sh; then
        print_success "Setup completed successfully!"
        echo ""
    else
        print_error "Setup failed. Please check errors above."
        exit 1
    fi
fi
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Helper functions
print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${YELLOW}ℹ${NC} $1"
}

# Check prerequisites
echo "Checking prerequisites..."

if ! command -v docker &> /dev/null; then
    print_error "Docker is not installed. Please install Docker first."
    exit 1
fi
print_success "Docker is installed"

if ! command -v docker-compose &> /dev/null; then
    print_error "Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi
print_success "Docker Compose is installed"

# Check if docker daemon is running
if ! docker info &> /dev/null; then
    print_error "Docker daemon is not running. Please start Docker service."
    exit 1
fi
print_success "Docker daemon is running"

echo ""
echo "============================================"
echo "Step 1: Stopping existing containers"
echo "============================================"
docker-compose down 2>/dev/null || true
print_success "Stopped existing containers"

echo ""
echo "============================================"
echo "Step 2: Building Docker images"
echo "============================================"
print_info "This may take 10-20 minutes on first run..."

if docker-compose build; then
    print_success "All images built successfully"
else
    print_error "Build failed. Check logs above."
    exit 1
fi

echo ""
echo "============================================"
echo "Step 3: Starting services"
echo "============================================"
print_info "Starting all 11 microservices..."

if docker-compose up -d; then
    print_success "All services started"
else
    print_error "Failed to start services"
    exit 1
fi

echo ""
echo "============================================"
echo "Step 4: Waiting for services to be healthy"
echo "============================================"

sleep 10

# Check service health
SERVICES=("mongodb" "redis" "mysql" "rabbitmq" "catalogue" "user" "cart" "payment" "shipping")
UNHEALTHY_SERVICES=()

for service in "${SERVICES[@]}"; do
    if docker-compose ps | grep "$service" | grep -q "Up"; then
        print_success "$service is running"
    else
        print_error "$service is not running"
        UNHEALTHY_SERVICES+=("$service")
    fi
done

echo ""
echo "============================================"
echo "Step 5: Verification"
echo "============================================"

# Get server IP
SERVER_IP=$(curl -s http://checkip.amazonaws.com || echo "localhost")

echo ""
print_info "Service Status:"
docker-compose ps

echo ""
print_info "Testing endpoints..."

# Test frontend
if curl -sf http://localhost/ > /dev/null; then
    print_success "Frontend is accessible"
else
    print_error "Frontend is not accessible"
fi

# Test catalogue
if curl -sf http://localhost:8082/health > /dev/null; then
    print_success "Catalogue service is healthy"
else
    print_error "Catalogue service is not healthy"
fi

# Test user
if curl -sf http://localhost:8081/health > /dev/null; then
    print_success "User service is healthy"
else
    print_error "User service is not healthy"
fi

# Test cart
if curl -sf http://localhost:8083/health > /dev/null; then
    print_success "Cart service is healthy"
else
    print_error "Cart service is not healthy"
fi

# Test payment
if curl -sf http://localhost:8084/health > /dev/null; then
    print_success "Payment service is healthy"
else
    print_error "Payment service is not healthy"
fi

# Test shipping
if curl -sf http://localhost:8086/actuator/health > /dev/null; then
    print_success "Shipping service is healthy"
else
    print_error "Shipping service is not healthy"
fi

echo ""
echo "============================================"
echo "Deployment Complete!"
echo "============================================"
echo ""

if [ ${#UNHEALTHY_SERVICES[@]} -eq 0 ]; then
    print_success "All services are healthy and running!"
    echo ""
    echo "Access your application at:"
    echo "  🌐 Frontend: http://$SERVER_IP"
    echo "  📊 RabbitMQ Management: http://$SERVER_IP:15672"
    echo "     - Username: skillupworks"
    echo "     - Password: skillupworks@123"
    echo ""
    echo "Individual service endpoints:"
    echo "  • Catalogue: http://$SERVER_IP:8082/products"
    echo "  • User: http://$SERVER_IP:8081/health"
    echo "  • Cart: http://$SERVER_IP:8083/health"
    echo "  • Payment: http://$SERVER_IP:8084/health"
    echo "  • Shipping: http://$SERVER_IP:8086/count"
    echo ""
    print_info "View logs with: docker-compose logs -f"
    print_info "Stop services with: docker-compose stop"
    print_info "Restart services with: docker-compose restart"
else
    print_error "Some services are not healthy: ${UNHEALTHY_SERVICES[*]}"
    echo ""
    echo "To troubleshoot:"
    echo "  1. Check logs: docker-compose logs -f <service-name>"
    echo "  2. Restart service: docker-compose restart <service-name>"
    echo "  3. Rebuild service: docker-compose build <service-name> && docker-compose up -d <service-name>"
fi

echo ""
echo "============================================"
