# SkillUpWorks Docker Compose - Quick Reference Card

## 🚀 ONE-COMMAND DEPLOYMENT

```bash
cd ~/skillupworks && chmod +x setup.sh deploy.sh && ./setup.sh && ./deploy.sh
```

**Time:** 10-15 minutes | **Result:** All 11 services running ✅

---

## 📦 What Gets Deployed

| # | Service | Technology | Port | Auto-Downloaded from S3 |
|---|---------|-----------|------|------------------------|
| 1 | Frontend | Nginx | 80 | ✅ skillupworks-frontend.zip |
| 2 | Catalogue | Node.js 18 | 8082 | ✅ skillupworks-catalogue.zip |
| 3 | User | Node.js 18 | 8081 | ✅ skillupworks-user.zip |
| 4 | Cart | Node.js 18 | 8083 | ✅ skillupworks-cart.zip |
| 5 | Payment | Python 3.11 | 8084 | ✅ skillupworks-payment.zip |
| 6 | Shipping | Java 17 | 8086 | ✅ skillupworks-shipping.zip |
| 7 | Order Processor | Python 3.11 | - | ✅ skillupworks-order-processor.zip |
| 8 | MongoDB | MongoDB 7.0 | 27017 | Built-in |
| 9 | Redis | Redis 7 | 6379 | Built-in |
| 10 | MySQL | MySQL 8.4 | 3306 | Built-in |
| 11 | RabbitMQ | RabbitMQ 3.13 | 5672, 15672 | Built-in |

---

## 📋 Prerequisites (One-Time Setup)

```bash
# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Verify
docker --version && docker-compose --version
```

**Server:** t3.large+ (4 vCPU, 8GB RAM, 50GB disk)

---

## 🎯 Two-Script Deployment

### Script 1: setup.sh (Downloads Source Code)
```bash
./setup.sh
```

**What it does:**
- ✅ Downloads all 7 services from S3
- ✅ Creates directory structure
- ✅ Sets up MongoDB init script
- ✅ Copies MySQL init script
- ✅ Verifies all files present

**Time:** 2-3 minutes

---

### Script 2: deploy.sh (Builds & Starts Everything)
```bash
./deploy.sh
```

**What it does:**
- ✅ Checks Docker installed
- ✅ Stops existing containers
- ✅ Builds all 11 Docker images
- ✅ Starts all services
- ✅ Runs health checks
- ✅ Shows access URLs

**Time:** 8-12 minutes

---

## ✅ Verification (30 seconds)

```bash
# Check all services running
docker-compose ps

# View logs
docker-compose logs -f

# Test endpoints
curl http://localhost:8082/products  # Catalogue
curl http://localhost:8081/health    # User
curl http://localhost:8083/health    # Cart
curl http://localhost:8084/health    # Payment
curl http://localhost:8086/count     # Shipping

# Access frontend
SERVER_IP=$(curl -s http://checkip.amazonaws.com)
echo "Frontend: http://$SERVER_IP"
echo "RabbitMQ UI: http://$SERVER_IP:15672"
```

---

## 🔧 Common Commands

```bash
# Start all services
docker-compose start

# Stop all services
docker-compose stop

# Restart all services
docker-compose restart

# Restart one service
docker-compose restart payment

# View logs (all)
docker-compose logs -f

# View logs (one service)
docker-compose logs -f payment

# Check status
docker-compose ps

# Check resource usage
docker stats

# Update a service
docker-compose build payment
docker-compose up -d --no-deps payment

# Scale a service
docker-compose up -d --scale order-processor=3

# Remove everything
docker-compose down

# Remove everything + data
docker-compose down -v
```

---

## 🐛 Quick Troubleshooting

### Service won't start?
```bash
docker-compose logs <service>
docker-compose restart <service>
```

### Port already in use?
```bash
sudo netstat -tulpn | grep <PORT>
sudo kill -9 <PID>
```

### Out of memory?
```bash
docker stats
# Increase server RAM or add limits in docker-compose.yml
```

### Database connection failed?
```bash
docker-compose logs mongodb
docker-compose restart mongodb
```

### Need to rebuild?
```bash
docker-compose down
docker-compose build --no-cache
docker-compose up -d
```

---

## 📊 Access Points

After deployment:

| Service | URL | Credentials |
|---------|-----|-------------|
| **Frontend** | http://SERVER_IP | - |
| **RabbitMQ UI** | http://SERVER_IP:15672 | skillupworks / skillupworks@123 |
| **Catalogue API** | http://SERVER_IP:8082/products | - |
| **User API** | http://SERVER_IP:8081/health | - |
| **Cart API** | http://SERVER_IP:8083/health | - |
| **Payment API** | http://SERVER_IP:8084/health | - |
| **Shipping API** | http://SERVER_IP:8086/count | - |

---

## 📁 Files Included

```
SkillUpWorks-Docker/
├── setup.sh                    # Downloads source code
├── deploy.sh                   # Deploys everything
├── docker-compose.yml          # Orchestration
├── README.md                   # Documentation
├── DOCKER_SETUP_GUIDE.md       # Complete guide
├── DEPLOYMENT_SUMMARY.md       # Architecture overview
│
├── catalogue-service/Dockerfile
├── user-service/Dockerfile
├── cart-service/Dockerfile
├── payment-service/Dockerfile
├── order-processor/Dockerfile
├── shipping-service/Dockerfile
└── frontend/Dockerfile + nginx.conf
```

---

## 🎓 For Teaching

**Docker Module:**
- Show docker-compose.yml structure
- Explain networking between containers
- Demonstrate volume persistence
- Show health checks

**Kubernetes Module:**
- Compare with K8s manifests
- Show scaling differences
- Demonstrate service discovery

**CI/CD Module:**
- Automate with Jenkins/GitHub Actions
- Build images in pipeline
- Deploy to environments

---

## 💾 Backup

```bash
# MongoDB
docker exec skillupworks-mongodb mongodump --out /backup
docker cp skillupworks-mongodb:/backup ./mongodb-backup

# MySQL
docker exec skillupworks-mysql mysqldump -u root -pskillupworks@1990 cities > mysql-backup.sql

# Redis
docker exec skillupworks-redis redis-cli SAVE
docker cp skillupworks-redis:/data/dump.rdb ./redis-backup.rdb
```

---

## 🔒 Security Checklist

Before production:
- [ ] Change MySQL password (skillupworks@1990)
- [ ] Change RabbitMQ password (skillupworks@123)
- [ ] Enable SSL/HTTPS on Nginx
- [ ] Add resource limits
- [ ] Configure firewall (only port 80/443 public)
- [ ] Set up automated backups
- [ ] Enable monitoring/logging

---

## 📞 Support

**Issues?**
1. Check logs: `docker-compose logs -f <service>`
2. Review DOCKER_SETUP_GUIDE.md
3. Verify prerequisites installed
4. Check server resources (CPU/RAM/Disk)

---

## ⏱️ Deployment Timeline

```
00:00 - Run setup.sh
02:00 - Source code downloaded ✅
02:01 - Run deploy.sh
03:00 - Images building...
10:00 - Services starting...
12:00 - Health checks passing ✅
12:30 - Application ready! 🎉
```

**Total: ~12-15 minutes from zero to running**

---

## 🎉 Success Indicators

All these should work:
- ✅ `docker-compose ps` shows all services "Up" and "healthy"
- ✅ `curl http://localhost/` returns HTML
- ✅ `curl http://localhost:8082/products` returns JSON
- ✅ Frontend loads in browser
- ✅ Can register user and add items to cart
- ✅ Payment processing works
- ✅ Orders appear in RabbitMQ

---

**Ready to deploy? Run:**
```bash
./setup.sh && ./deploy.sh
```

**🚀 Your SkillUpWorks platform will be live in 15 minutes!**
