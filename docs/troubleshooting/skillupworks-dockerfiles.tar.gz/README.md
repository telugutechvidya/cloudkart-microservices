# SkillUpWorks Docker Compose - Complete Package

## 📦 What's Included

This package contains everything you need to deploy all 11 SkillUpWorks microservices using Docker Compose on a single server.

### Files Provided

```
📁 SkillUpWorks-Docker/
├── 📄 docker-compose.yml          # Main orchestration file
├── 📄 DOCKER_SETUP_GUIDE.md       # Complete setup guide
├── 📄 deploy.sh                   # Automated deployment script
├── 📄 README.md                   # This file
│
├── 📁 catalogue-service/
│   └── Dockerfile
├── 📁 user-service/
│   └── Dockerfile
├── 📁 cart-service/
│   └── Dockerfile
├── 📁 payment-service/
│   └── Dockerfile
├── 📁 order-processor/
│   └── Dockerfile
├── 📁 shipping-service/
│   └── Dockerfile
└── 📁 frontend/
    ├── Dockerfile
    └── nginx.conf
```

---

## 🚀 Quick Start (2 Commands!)

```bash
# 1. Download this package and extract
unzip SkillUpWorks-Docker.zip
cd SkillUpWorks-Docker

# 2. Run automated setup and deployment
chmod +x setup.sh deploy.sh
./setup.sh    # Downloads all source code from S3
./deploy.sh   # Builds and starts all services
```

**That's it!** Your complete application will be running in 10-15 minutes.

The setup script automatically downloads all 7 microservices from S3:
- ✅ skillupworks-catalogue.zip
- ✅ skillupworks-user.zip
- ✅ skillupworks-cart.zip
- ✅ skillupworks-payment.zip
- ✅ skillupworks-order-processor.zip
- ✅ skillupworks-shipping.zip
- ✅ skillupworks-frontend.zip

---

## 📋 Prerequisites

### Server Requirements
- **CPU:** 4 vCPUs minimum (t3.large or equivalent)
- **RAM:** 8GB minimum (16GB recommended)
- **Disk:** 50GB minimum
- **OS:** Ubuntu 20.04+, RHEL 8+, or Amazon Linux 2023

### Software Requirements
```bash
# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Verify
docker --version
docker-compose --version
```

---

## 🏗️ Architecture

### All 11 Services:

**Frontend:**
- Nginx (Port 80)

**Databases:**
- MongoDB (Port 27017)
- Redis (Port 6379)
- MySQL (Port 3306)

**Message Queue:**
- RabbitMQ (Ports 5672, 15672)

**Backend Services:**
- Catalogue Service - Node.js (Port 8082)
- User Service - Node.js (Port 8081)
- Cart Service - Node.js (Port 8083)
- Payment Service - Python (Port 8084)
- Order Processor - Python (Background)
- Shipping Service - Java (Port 8086)

---

## 📝 Step-by-Step Setup

### 1. Prepare Server & Download Package

```bash
# Create directory
mkdir ~/skillupworks && cd ~/skillupworks

# Copy/extract the Docker package here
# All files from this package should be in ~/skillupworks/
```

### 2. Run Automated Setup

```bash
# This script automatically:
# - Downloads all 7 microservices from S3
# - Creates directory structure
# - Sets up database init scripts
# - Verifies all files are present

chmod +x setup.sh
./setup.sh
```

**What setup.sh downloads:**
- Catalogue Service (Node.js)
- User Service (Node.js)
- Cart Service (Node.js)
- Payment Service (Python)
- Order Processor (Python)
- Shipping Service (Java)
- Frontend (HTML/CSS/JS)

### 3. Deploy with Docker Compose

```bash
# This script:
# - Checks prerequisites
# - Builds all Docker images
# - Starts all 11 services
# - Runs health checks
# - Displays access URLs

chmod +x deploy.sh
./deploy.sh
```

**Done!** All 11 services will be running.

---

## ✅ Verification

### Check All Services
```bash
docker-compose ps
```

Expected: All services show "Up" and "healthy"

### Test Individual Services
```bash
# Get your server IP
SERVER_IP=$(curl -s http://checkip.amazonaws.com)

# Test services
curl http://localhost:8082/products  # Catalogue
curl http://localhost:8081/health    # User
curl http://localhost:8083/health    # Cart
curl http://localhost:8084/health    # Payment
curl http://localhost:8086/count     # Shipping

# Access frontend
open http://$SERVER_IP
```

### View Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f payment

# Last 100 lines
docker-compose logs --tail=100
```

---

## 🔧 Common Operations

### Start/Stop Services
```bash
docker-compose start    # Start all
docker-compose stop     # Stop all
docker-compose restart  # Restart all
```

### Update a Service
```bash
# Make code changes
# Rebuild and redeploy
docker-compose build <service>
docker-compose up -d --no-deps <service>
```

### Scale Services
```bash
# Run 3 order processors
docker-compose up -d --scale order-processor=3
```

### Clean Up
```bash
# Stop and remove containers
docker-compose down

# Remove everything including data
docker-compose down -v --rmi all
```

---

## 🐛 Troubleshooting

### Service Won't Start
```bash
# Check logs
docker-compose logs <service>

# Restart service
docker-compose restart <service>

# Rebuild service
docker-compose build <service>
docker-compose up -d <service>
```

### Port Already in Use
```bash
# Find what's using the port
sudo netstat -tulpn | grep <PORT>

# Kill the process
sudo kill -9 <PID>
```

### Out of Memory
```bash
# Check memory usage
docker stats

# Add memory limits to docker-compose.yml
services:
  shipping:
    mem_limit: 2g
```

### Database Connection Issues
```bash
# Check database health
docker-compose ps mongodb
docker-compose logs mongodb

# Restart database
docker-compose restart mongodb
```

---

## 📊 Monitoring

### Real-time Stats
```bash
docker stats
```

### Application Monitoring
- **RabbitMQ UI:** http://<SERVER_IP>:15672
  - Username: skillupworks
  - Password: skillupworks@123

### Service Health Endpoints
- Catalogue: http://localhost:8082/health
- User: http://localhost:8081/health
- Cart: http://localhost:8083/health
- Payment: http://localhost:8084/health
- Shipping: http://localhost:8086/actuator/health

---

## 💾 Backup & Restore

### Backup
```bash
# MongoDB
docker exec skillupworks-mongodb mongodump --out /backup
docker cp skillupworks-mongodb:/backup ./mongodb-backup

# MySQL
docker exec skillupworks-mysql mysqldump -u root -pskillupworks@1990 cities > mysql-backup.sql

# Redis
docker exec skillupworks-redis redis-cli SAVE
docker cp skillupworks-redis:/data/dump.rdb ./redis-backup.rdb
```

### Restore
```bash
# MongoDB
docker cp ./mongodb-backup skillupworks-mongodb:/backup
docker exec skillupworks-mongodb mongorestore /backup

# MySQL
docker exec -i skillupworks-mysql mysql -u root -pskillupworks@1990 cities < mysql-backup.sql
```

---

## 🔒 Security Notes

### Change Default Passwords

Before production deployment, change these passwords:

```yaml
# In docker-compose.yml

# MySQL
MYSQL_ROOT_PASSWORD: YOUR_SECURE_PASSWORD

# RabbitMQ
RABBITMQ_DEFAULT_USER: YOUR_USERNAME
RABBITMQ_DEFAULT_PASS: YOUR_SECURE_PASSWORD

# Update in all service environment variables too
```

### Firewall Configuration

Only expose necessary ports publicly:
- Port 80 (HTTP) - Public
- Port 443 (HTTPS) - Public (if SSL enabled)
- All other ports - Private/Internal only

---

## 📚 Additional Resources

- **Complete Guide:** See `DOCKER_SETUP_GUIDE.md`
- **GitHub Docs:** https://github.com/telugutechvidya/cloudkart-microservices
- **Docker Docs:** https://docs.docker.com/compose/

---

## 🎯 Testing Checklist

- [ ] All containers running
- [ ] All health checks passing
- [ ] Frontend accessible
- [ ] User registration works
- [ ] Product catalog loads
- [ ] Add to cart works
- [ ] Checkout process works
- [ ] Payment processing works
- [ ] Order appears in RabbitMQ
- [ ] Order processor handles orders
- [ ] Shipping calculation works

---

## 💡 Tips

1. **First deployment takes time** - Building images can take 10-20 minutes
2. **Subsequent deployments are fast** - Docker caches layers
3. **Monitor logs during startup** - `docker-compose logs -f`
4. **Wait for health checks** - Services need 2-3 minutes to be fully ready
5. **Use deploy.sh** - Automates everything with error checking

---

## 🆘 Getting Help

If you encounter issues:

1. **Check logs first:** `docker-compose logs -f <service>`
2. **Review DOCKER_SETUP_GUIDE.md** - Detailed troubleshooting
3. **Verify prerequisites** - Docker, Docker Compose installed
4. **Check server resources** - Adequate CPU/RAM/Disk
5. **Restart services** - `docker-compose restart`

---

## ✨ What's Next?

After successful deployment:

1. **Test the application thoroughly**
2. **Configure SSL/HTTPS** for production
3. **Set up automated backups**
4. **Configure monitoring/alerts**
5. **Document your specific setup**
6. **Plan scaling strategy**

---

## 🎉 Success!

If you see this, you're ready to deploy:

```bash
cd ~/skillupworks
./deploy.sh
```

Your complete SkillUpWorks application will be running in minutes!

**Access:** http://<YOUR-SERVER-IP>

---

**Created with ❤️ for SkillUpWorks DevOps Education Platform**
