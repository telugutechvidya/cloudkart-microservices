#!/bin/bash

# ============================================================================
# SkillUpWorks - Preparation Script
# Run this ONCE after extracting the Docker package
# Copies Dockerfiles to service directories
# ============================================================================

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_success() { echo -e "${GREEN}✓${NC} $1"; }
print_info() { echo -e "${YELLOW}ℹ${NC} $1"; }
print_error() { echo -e "${RED}✗${NC} $1"; }

echo "============================================"
echo "SkillUpWorks - Preparation"
echo "============================================"
echo ""

# Create service directories
print_info "Creating service directories..."
mkdir -p catalogue-service user-service cart-service payment-service order-processor shipping-service frontend/html
mkdir -p mongo-init mysql-init
print_success "Directories created"

# Check if Dockerfiles directory exists
if [ -d "dockerfiles" ]; then
    print_info "Copying Dockerfiles from dockerfiles/ directory..."
    
    cp dockerfiles/Dockerfile.catalogue catalogue-service/Dockerfile 2>/dev/null && print_success "Catalogue Dockerfile copied"
    cp dockerfiles/Dockerfile.user user-service/Dockerfile 2>/dev/null && print_success "User Dockerfile copied"
    cp dockerfiles/Dockerfile.cart cart-service/Dockerfile 2>/dev/null && print_success "Cart Dockerfile copied"
    cp dockerfiles/Dockerfile.payment payment-service/Dockerfile 2>/dev/null && print_success "Payment Dockerfile copied"
    cp dockerfiles/Dockerfile.order-processor order-processor/Dockerfile 2>/dev/null && print_success "Order Processor Dockerfile copied"
    cp dockerfiles/Dockerfile.shipping shipping-service/Dockerfile 2>/dev/null && print_success "Shipping Dockerfile copied"
    cp dockerfiles/Dockerfile.frontend frontend/Dockerfile 2>/dev/null && print_success "Frontend Dockerfile copied"
    cp dockerfiles/nginx.conf frontend/ 2>/dev/null && print_success "nginx.conf copied"
    
elif [ -f "catalogue-service/Dockerfile" ]; then
    print_success "Dockerfiles already in place"
else
    # Look for Dockerfiles with naming pattern
    print_info "Looking for Dockerfiles in current directory..."
    
    [ -f "Dockerfile.catalogue" ] && cp Dockerfile.catalogue catalogue-service/Dockerfile && print_success "Catalogue Dockerfile copied"
    [ -f "Dockerfile.user" ] && cp Dockerfile.user user-service/Dockerfile && print_success "User Dockerfile copied"
    [ -f "Dockerfile.cart" ] && cp Dockerfile.cart cart-service/Dockerfile && print_success "Cart Dockerfile copied"
    [ -f "Dockerfile.payment" ] && cp Dockerfile.payment payment-service/Dockerfile && print_success "Payment Dockerfile copied"
    [ -f "Dockerfile.order-processor" ] && cp Dockerfile.order-processor order-processor/Dockerfile && print_success "Order Processor Dockerfile copied"
    [ -f "Dockerfile.shipping" ] && cp Dockerfile.shipping shipping-service/Dockerfile && print_success "Shipping Dockerfile copied"
    [ -f "Dockerfile.frontend" ] && cp Dockerfile.frontend frontend/Dockerfile && print_success "Frontend Dockerfile copied"
    [ -f "nginx.conf" ] && cp nginx.conf frontend/ && print_success "nginx.conf copied"
fi

echo ""
print_info "Verifying Dockerfiles..."

MISSING=()
[ ! -f "catalogue-service/Dockerfile" ] && MISSING+=("catalogue-service/Dockerfile")
[ ! -f "user-service/Dockerfile" ] && MISSING+=("user-service/Dockerfile")
[ ! -f "cart-service/Dockerfile" ] && MISSING+=("cart-service/Dockerfile")
[ ! -f "payment-service/Dockerfile" ] && MISSING+=("payment-service/Dockerfile")
[ ! -f "order-processor/Dockerfile" ] && MISSING+=("order-processor/Dockerfile")
[ ! -f "shipping-service/Dockerfile" ] && MISSING+=("shipping-service/Dockerfile")
[ ! -f "frontend/Dockerfile" ] && MISSING+=("frontend/Dockerfile")
[ ! -f "frontend/nginx.conf" ] && MISSING+=("frontend/nginx.conf")

if [ ${#MISSING[@]} -eq 0 ]; then
    print_success "All Dockerfiles present"
else
    print_error "Missing files:"
    for file in "${MISSING[@]}"; do
        echo "  - $file"
    done
    echo ""
    print_info "Please ensure you have the complete Docker package"
    exit 1
fi

echo ""
print_success "Preparation complete!"
echo ""
echo "Next steps:"
echo "  1. Run: ./setup.sh     (downloads source code from S3)"
echo "  2. Run: ./deploy.sh    (builds and starts everything)"
echo ""
