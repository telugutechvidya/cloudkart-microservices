// ===============================
// CloudKart Cart Service - FINAL CORRECTED VERSION
// ===============================

const redis = require('redis');
const request = require('request');
const bodyParser = require('body-parser');
const express = require('express');
const pino = require('pino');
const expPino = require('express-pino-logger');

// Prometheus
const promClient = require('prom-client');
const Registry = promClient.Registry;
const register = new Registry();
const counter = new promClient.Counter({
    name: 'items_added',
    help: 'running count of items added to cart',
    registers: [register]
});

let redisConnected = false;

// ENV VARIABLES
const redisHost = process.env.REDIS_HOST || 'redis';
// NOTE: CATALOGUE_PORT is correctly set to 8082 here, based on your working Nginx config.
const catalogueHost = process.env.CATALOGUE_HOST || 'catalogue';
const cataloguePort = process.env.CATALOGUE_PORT || '8082';

// Logging setup
const logger = pino({
    level: 'info',
    prettyPrint: false,
    useLevelLabels: true
});
const expLogger = expPino({ logger });

const app = express();
app.use(expLogger);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// CORS
app.use((req, res, next) => {
    res.set('Access-Control-Allow-Origin', '*');
    next();
});

// Get X-Session-Id
function getSessionId(req) {
    const sessionId = req.header("X-Session-Id");
    if (!sessionId) req.log.warn("Missing X-Session-Id header");
    return sessionId;
}

// Health check
app.get('/health', (req, res) => {
    res.json({ app: "OK", redis: redisConnected });
});

// Prometheus metrics
app.get('/metrics', (req, res) => {
    res.header("Content-Type", "text/plain");
    res.send(register.metrics());
});

// ===============================
// REDIS v4 CLIENT
// ===============================
const redisClient = redis.createClient({
    socket: {
        host: redisHost,
        port: 6379
    }
});

(async () => {
    try {
        await redisClient.connect();
        redisConnected = true;
        logger.info("Redis connected successfully");
    } catch (err) {
        logger.error("Redis connection failed:", err);
    }
})();

// ===============================
// GET CART (Load Cart)
// ===============================
app.get('/', async (req, res) => {
    const sessionId = getSessionId(req);
    if (!sessionId) return res.json({ total: 0, tax: 0, items: [] });

    try {
        const data = await redisClient.get(`cart:${sessionId}`);
        if (!data) return res.json({ total: 0, tax: 0, items: [] });
        res.json(JSON.parse(data));
    } catch (err) {
        req.log.error(err);
        res.status(500).send("Cart read error");
    }
});

// ===============================
// DELETE CART
// ===============================
app.delete('/', async (req, res) => {
    const sessionId = getSessionId(req);
    if (!sessionId) return res.status(401).send("Session required");

    try {
        const del = await redisClient.del(`cart:${sessionId}`);
        if (del === 1) return res.send("OK");
        res.status(404).send("cart not found");
    } catch (err) {
        req.log.error(err);
        res.status(500).send("Delete failed");
    }
});

// ===============================
// ADD ITEM TO CART
// ===============================
app.post('/items', async (req, res) => {
    const sessionId = getSessionId(req);
    if (!sessionId) return res.status(401).send("Session required");

    const { sku, qty } = req.body;
    const quantity = parseInt(qty);

    if (isNaN(quantity) || quantity < 1) {
        return res.status(400).send("Invalid quantity");
    }

    try {
        // FIX: This URL was causing a 404/500 upstream, leading to null product data.
        const product = await getProduct(sku);
        if (!product) return res.status(404).send("product not found or Catalogue service unavailable");
        if (product.instock === 0) return res.status(404).send("out of stock");

        let cartData = await redisClient.get(`cart:${sessionId}`);
        let cart = cartData ? JSON.parse(cartData) : { total: 0, tax: 0, items: [] };

        // Item object is created here with correct price and subtotal
        const item = {
            sku,
            qty: quantity,
            name: product.name,
            price: product.price,
            subtotal: product.price * quantity
        };

        // mergeList function (see below) handles adding the item or updating quantity
        cart.items = mergeList(cart.items, item, quantity);
        cart.total = calcTotal(cart.items);
        cart.tax = calcTax(cart.total);

        await redisClient.setEx(`cart:${sessionId}`, 3600, JSON.stringify(cart));
        counter.inc(quantity);
        res.json(cart);

    } catch (err) {
        req.log.error(err);
        res.status(500).send("add failed");
    }
});

// ===============================
// UPDATE ITEM QTY
// ===============================
app.post('/update', async (req, res) => {
    const sessionId = getSessionId(req);
    if (!sessionId) return res.status(401).send("Session required");

    const { sku, qty } = req.body;
    const quantity = parseInt(qty);

    if (isNaN(quantity) || quantity < 0) {
        return res.status(400).send("Invalid quantity");
    }

    try {
        const data = await redisClient.get(`cart:${sessionId}`);
        if (!data) return res.status(404).send("cart not found");

        let cart = JSON.parse(data);
        const index = cart.items.findIndex(i => i.sku === sku);

        if (index === -1) return res.status(404).send("not in cart");

        if (quantity === 0) {
            cart.items.splice(index, 1);
        } else {
            cart.items[index].qty = quantity;
            cart.items[index].subtotal = cart.items[index].price * quantity;
        }

        cart.total = calcTotal(cart.items);
        cart.tax = calcTax(cart.total);

        await redisClient.setEx(`cart:${sessionId}`, 3600, JSON.stringify(cart));
        res.json(cart);

    } catch (err) {
        req.log.error(err);
        res.status(500).send("update failed");
    }
});

// ===============================
// SHIPPING
// ===============================
app.post('/shipping', async (req, res) => {
    const sessionId = getSessionId(req);
    if (!sessionId) return res.status(401).send("Session required");

    try {
        const data = await redisClient.get(`cart:${sessionId}`);
        if (!data) return res.status(404).send("cart not found");

        let cart = JSON.parse(data);
        cart.shipping = req.body;

        await redisClient.setEx(`cart:${sessionId}`, 3600, JSON.stringify(cart));
        res.json(cart);

    } catch (err) {
        req.log.error(err);
        res.status(500).send("shipping update failed");
    }
});

// ===============================
// Helper Functions
// ===============================
function mergeList(list, item, qty) {
    const index = list.findIndex(i => i.sku === item.sku);
    if (index >= 0) {
        // Item found: Update existing quantity
        list[index].qty += qty;
        list[index].subtotal = list[index].price * list[index].qty;
    } else {
        // Item not found: Add the pre-calculated item object
        list.push(item);
    }
    return list;
}

function calcTotal(list) {
    return list.reduce((sum, item) => sum + item.subtotal, 0);
}

function calcTax(total) {
    return total - total / 1.2; // 20% VAT
}

// ===============================
// CATALOGUE FETCH FUNCTIONS
// ===============================

// FIX: Corrected URL from /product/ to /products/ to match Roboshop/Catalogue API standard

function getProduct(sku) {
    return new Promise((resolve, reject) => {
        request(`http://${catalogueHost}:${cataloguePort}/product/${sku}`, (err, res, body) => {
            if (err) return reject(err);
            if (res.statusCode !== 200) return resolve(null);

            try {
                const productData = JSON.parse(body);

                // FIX: Check if the response is an empty array or empty object.
                // The Catalogue service returns [] when a product isn't found.
                if (Array.isArray(productData) && productData.length === 0) {
                    return resolve(null);
                }

                // If it's a valid object, return it.
                resolve(productData);
            } catch (e) {
                reject(e);
            }
        });
    });
}
// ===============================
// START SERVER
// ===============================
// Set port to 8083 to match your Nginx proxy configuration
const port = process.env.CART_SERVER_PORT || 8083; 
app.listen(port, () => {
    logger.info("Cart Service started on port", port);
});
