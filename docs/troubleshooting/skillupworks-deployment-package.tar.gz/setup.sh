#!/bin/bash

# ============================================================================
# SkillUpWorks - Automated Setup Script
# Downloads all source code from S3 and prepares for Docker deployment
# ============================================================================

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Helper functions
print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${YELLOW}ℹ${NC} $1"
}

print_header() {
    echo -e "${BLUE}================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}================================${NC}"
}

# S3 URLs
S3_BASE_URL="https://skillupworks.s3.us-east-1.amazonaws.com"
CATALOGUE_ZIP="${S3_BASE_URL}/skillupworks-catalogue.zip"
USER_ZIP="${S3_BASE_URL}/skillupworks-user.zip"
CART_ZIP="${S3_BASE_URL}/skillupworks-cart.zip"
PAYMENT_ZIP="${S3_BASE_URL}/skillupworks-payment.zip"
ORDER_PROCESSOR_ZIP="${S3_BASE_URL}/skillupworks-order-processor.zip"
SHIPPING_ZIP="${S3_BASE_URL}/skillupworks-shipping.zip"
FRONTEND_ZIP="${S3_BASE_URL}/skillupworks-frontend.zip"

echo ""
print_header "SkillUpWorks - Automated Setup"
echo ""

# Check prerequisites
print_info "Checking prerequisites..."

if ! command -v curl &> /dev/null; then
    print_error "curl is not installed. Please install curl first."
    exit 1
fi
print_success "curl is installed"

if ! command -v unzip &> /dev/null; then
    print_error "unzip is not installed. Please install unzip first."
    exit 1
fi
print_success "unzip is installed"

echo ""
print_header "Step 1: Creating Directory Structure"

# Create service directories
mkdir -p catalogue-service user-service cart-service payment-service order-processor shipping-service frontend/html
mkdir -p mongo-init mysql-init

print_success "Directories created"

echo ""
print_header "Step 2: Downloading Source Code from S3"

# Download Catalogue Service
print_info "Downloading Catalogue Service..."
if curl -f -o /tmp/catalogue.zip "$CATALOGUE_ZIP" 2>/dev/null; then
    cd catalogue-service
    unzip -q /tmp/catalogue.zip
    rm /tmp/catalogue.zip
    cd ..
    print_success "Catalogue Service downloaded"
else
    print_error "Failed to download Catalogue Service"
    exit 1
fi

# Download User Service
print_info "Downloading User Service..."
if curl -f -o /tmp/user.zip "$USER_ZIP" 2>/dev/null; then
    cd user-service
    unzip -q /tmp/user.zip
    rm /tmp/user.zip
    cd ..
    print_success "User Service downloaded"
else
    print_error "Failed to download User Service"
    exit 1
fi

# Download Cart Service
print_info "Downloading Cart Service..."
if curl -f -o /tmp/cart.zip "$CART_ZIP" 2>/dev/null; then
    cd cart-service
    unzip -q /tmp/cart.zip
    rm /tmp/cart.zip
    cd ..
    print_success "Cart Service downloaded"
else
    print_error "Failed to download Cart Service"
    exit 1
fi

# Download Payment Service
print_info "Downloading Payment Service..."
if curl -f -o /tmp/payment.zip "$PAYMENT_ZIP" 2>/dev/null; then
    cd payment-service
    unzip -q /tmp/payment.zip
    rm /tmp/payment.zip
    cd ..
    print_success "Payment Service downloaded"
else
    print_error "Failed to download Payment Service"
    exit 1
fi

# Download Order Processor
print_info "Downloading Order Processor..."
if curl -f -o /tmp/order-processor.zip "$ORDER_PROCESSOR_ZIP" 2>/dev/null; then
    cd order-processor
    unzip -q /tmp/order-processor.zip
    rm /tmp/order-processor.zip
    cd ..
    print_success "Order Processor downloaded"
else
    print_error "Failed to download Order Processor"
    exit 1
fi

# Download Shipping Service
print_info "Downloading Shipping Service..."
if curl -f -o /tmp/shipping.zip "$SHIPPING_ZIP" 2>/dev/null; then
    cd shipping-service
    unzip -q /tmp/shipping.zip
    rm /tmp/shipping.zip
    cd ..
    print_success "Shipping Service downloaded"
else
    print_error "Failed to download Shipping Service"
    exit 1
fi

# Download Frontend
print_info "Downloading Frontend..."
if curl -f -o /tmp/frontend.zip "$FRONTEND_ZIP" 2>/dev/null; then
    cd frontend
    unzip -q /tmp/frontend.zip -d html/
    rm /tmp/frontend.zip
    cd ..
    print_success "Frontend downloaded"
else
    print_error "Failed to download Frontend"
    exit 1
fi

echo ""
print_header "Step 3: Setting Up Dockerfiles"

# Copy Dockerfiles to each service directory
print_info "Copying Dockerfiles to service directories..."

# Check if Dockerfiles exist in current directory or subdirectories
DOCKERFILES_FOUND=false

# Copy Catalogue Dockerfile
if [ -f "catalogue-service/Dockerfile" ]; then
    print_success "Catalogue Dockerfile already present"
    DOCKERFILES_FOUND=true
elif [ -f "Dockerfile.catalogue" ]; then
    cp Dockerfile.catalogue catalogue-service/Dockerfile
    print_success "Copied Catalogue Dockerfile"
    DOCKERFILES_FOUND=true
fi

# Copy User Dockerfile
if [ -f "user-service/Dockerfile" ]; then
    print_success "User Dockerfile already present"
    DOCKERFILES_FOUND=true
elif [ -f "Dockerfile.user" ]; then
    cp Dockerfile.user user-service/Dockerfile
    print_success "Copied User Dockerfile"
    DOCKERFILES_FOUND=true
fi

# Copy Cart Dockerfile
if [ -f "cart-service/Dockerfile" ]; then
    print_success "Cart Dockerfile already present"
    DOCKERFILES_FOUND=true
elif [ -f "Dockerfile.cart" ]; then
    cp Dockerfile.cart cart-service/Dockerfile
    print_success "Copied Cart Dockerfile"
    DOCKERFILES_FOUND=true
fi

# Copy Payment Dockerfile
if [ -f "payment-service/Dockerfile" ]; then
    print_success "Payment Dockerfile already present"
    DOCKERFILES_FOUND=true
elif [ -f "Dockerfile.payment" ]; then
    cp Dockerfile.payment payment-service/Dockerfile
    print_success "Copied Payment Dockerfile"
    DOCKERFILES_FOUND=true
fi

# Copy Order Processor Dockerfile
if [ -f "order-processor/Dockerfile" ]; then
    print_success "Order Processor Dockerfile already present"
    DOCKERFILES_FOUND=true
elif [ -f "Dockerfile.order-processor" ]; then
    cp Dockerfile.order-processor order-processor/Dockerfile
    print_success "Copied Order Processor Dockerfile"
    DOCKERFILES_FOUND=true
fi

# Copy Shipping Dockerfile
if [ -f "shipping-service/Dockerfile" ]; then
    print_success "Shipping Dockerfile already present"
    DOCKERFILES_FOUND=true
elif [ -f "Dockerfile.shipping" ]; then
    cp Dockerfile.shipping shipping-service/Dockerfile
    print_success "Copied Shipping Dockerfile"
    DOCKERFILES_FOUND=true
fi

# Copy Frontend Dockerfile and nginx.conf
if [ -f "frontend/Dockerfile" ]; then
    print_success "Frontend Dockerfile already present"
    DOCKERFILES_FOUND=true
elif [ -f "Dockerfile.frontend" ]; then
    cp Dockerfile.frontend frontend/Dockerfile
    print_success "Copied Frontend Dockerfile"
    DOCKERFILES_FOUND=true
fi

if [ -f "frontend/nginx.conf" ]; then
    print_success "Frontend nginx.conf already present"
elif [ -f "nginx.conf" ]; then
    cp nginx.conf frontend/
    print_success "Copied nginx.conf"
fi

if [ "$DOCKERFILES_FOUND" = false ]; then
    print_error "No Dockerfiles found!"
    echo ""
    echo "Expected Dockerfiles in one of these locations:"
    echo "  - <service-name>/Dockerfile (already in service directory)"
    echo "  - Dockerfile.<service-name> (in root directory)"
    echo ""
    echo "Please ensure you have downloaded the complete Docker package with:"
    echo "  - docker-compose.yml"
    echo "  - All Dockerfiles"
    echo "  - setup.sh and deploy.sh"
    exit 1
fi

echo ""
print_header "Step 4: Setting Up Database Init Scripts"

# Create MongoDB init script
print_info "Creating MongoDB initialization script..."
cat > mongo-init/init-db.js << 'EOF'
// Initialize MongoDB databases and collections
print("Starting MongoDB initialization...");

// Switch to catalogue database
db = db.getSiblingDB('catalogue');

// Create products collection with sample data
db.products.insertMany([
  {
    sku: "Linux",
    name: "Linux Mastery",
    description: "Complete Linux administration from basics to advanced",
    price: 2999,
    image: "/images/linux.jpg",
    category: "DevOps",
    qty: 100
  },
  {
    sku: "Docker",
    name: "Docker Mastery: From Code to Containers",
    description: "Master containerization with Docker",
    price: 2999,
    image: "/images/docker.jpg",
    category: "DevOps",
    qty: 100
  },
  {
    sku: "Kubernetes",
    name: "Kubernetes In Action: Scale Like Netflix",
    description: "Production-grade Kubernetes orchestration",
    price: 3999,
    image: "/images/kubernetes.jpg",
    category: "DevOps",
    qty: 100
  },
  {
    sku: "Ansible",
    name: "Ansible Mastery: One Click, Everything",
    description: "Automate infrastructure with Ansible",
    price: 2999,
    image: "/images/ansible.jpg",
    category: "DevOps",
    qty: 100
  },
  {
    sku: "Terraform",
    name: "Terraform Mastery: Build Cloud With Code",
    description: "Infrastructure as Code with Terraform",
    price: 2999,
    image: "/images/terraform.jpg",
    category: "DevOps",
    qty: 100
  },
  {
    sku: "CICD",
    name: "CI/CD Mastery: Code to Production In Minutes",
    description: "Complete CI/CD pipeline automation",
    price: 2999,
    image: "/images/cicd.jpg",
    category: "DevOps",
    qty: 100
  },
  {
    sku: "Bash",
    name: "Bash Automation: From Manual to Magical",
    description: "Shell scripting and automation",
    price: 1999,
    image: "/images/bash.jpg",
    category: "DevOps",
    qty: 100
  },
  {
    sku: "AI",
    name: "AI for DevOps: Work Smarter, Not Harder",
    description: "AI-powered DevOps automation",
    price: 3999,
    image: "/images/ai.jpg",
    category: "AI",
    qty: 100
  }
]);

// Create indexes
db.products.createIndex({ sku: 1 }, { unique: true });
db.products.createIndex({ name: "text", description: "text" });

print("✓ Catalogue database initialized with " + db.products.countDocuments() + " products");

// Switch to users database
db = db.getSiblingDB('users');

// Create users collection (empty, will be populated on registration)
db.createCollection('users');

// Create indexes
db.users.createIndex({ username: 1 }, { unique: true });
db.users.createIndex({ email: 1 }, { unique: true });

print("✓ Users database initialized");
print("MongoDB initialization complete!");
EOF

print_success "MongoDB init script created"

# Check if shipping.sql exists in shipping-service
if [ -f "shipping-service/schema/shipping.sql" ]; then
    print_info "Copying shipping.sql to mysql-init..."
    cp shipping-service/schema/shipping.sql mysql-init/
    print_success "MySQL init script ready"
else
    print_info "shipping.sql not found in shipping-service/schema/"
    print_info "You may need to add it manually to mysql-init/"
fi

# Create payment.ini if not exists
if [ ! -f "payment-service/payment.ini" ]; then
    print_info "Creating payment.ini..."
    cat > payment-service/payment.ini << 'EOF'
[uwsgi]
module = payment:app
master = true
processes = 4
threads = 2
http = 0.0.0.0:8084
protocol = http
chmod-socket = 660
vacuum = true
die-on-term = true
EOF
    print_success "payment.ini created"
fi

echo ""
print_header "Step 5: Verification"

# Verify all source code is present
MISSING_FILES=()

# Check Node.js services
for service in catalogue user cart; do
    if [ ! -f "${service}-service/package.json" ]; then
        MISSING_FILES+=("${service}-service/package.json")
    fi
    if [ ! -f "${service}-service/server.js" ]; then
        MISSING_FILES+=("${service}-service/server.js")
    fi
done

# Check Python services
if [ ! -f "payment-service/payment.py" ]; then
    MISSING_FILES+=("payment-service/payment.py")
fi
if [ ! -f "payment-service/requirements.txt" ]; then
    MISSING_FILES+=("payment-service/requirements.txt")
fi
if [ ! -f "order-processor/order_processor.py" ]; then
    MISSING_FILES+=("order-processor/order_processor.py")
fi

# Check Java service
if [ ! -f "shipping-service/pom.xml" ]; then
    MISSING_FILES+=("shipping-service/pom.xml")
fi

# Check Frontend
if [ ! -f "frontend/html/index.html" ]; then
    MISSING_FILES+=("frontend/html/index.html")
fi

if [ ${#MISSING_FILES[@]} -eq 0 ]; then
    print_success "All required files are present"
else
    print_error "Some files are missing:"
    for file in "${MISSING_FILES[@]}"; do
        echo "  - $file"
    done
    echo ""
    print_info "Continuing anyway... Docker build will fail if files are truly missing."
fi

# Show directory structure
echo ""
print_info "Project structure:"
tree -L 2 -I 'node_modules|target' 2>/dev/null || ls -la

echo ""
print_header "Setup Complete!"
echo ""
print_success "All source code downloaded and ready!"
echo ""
echo "Next steps:"
echo "  1. Review the downloaded files"
echo "  2. Run: ./deploy.sh"
echo "  3. Access: http://\$(curl -s http://checkip.amazonaws.com)"
echo ""
print_info "Total services: 11 (7 application services + 4 databases/message queue)"
echo ""
