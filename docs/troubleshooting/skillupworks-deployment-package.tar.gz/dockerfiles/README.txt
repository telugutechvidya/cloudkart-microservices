These are the Dockerfiles for all SkillUpWorks services.

To use:
1. Upload this entire dockerfiles/ folder to your server
2. Place it in the same directory as prepare.sh
3. Run: ./prepare.sh

prepare.sh will automatically copy these files to the correct service directories.
